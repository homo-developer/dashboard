import DashboardPageLayout from "@/components/dashboard/layout"
import DashboardStat from "@/components/dashboard/stat"
import DashboardCard from "@/components/dashboard/card"
import CuteRobotIcon from "@/components/icons/cute-robot"
import GearIcon from "@/components/icons/gear"
import BoomIcon from "@/components/icons/boom"

export default function SecurityPage() {
  return (
    <DashboardPageLayout
      header={{
        title: "Security",
        description: "System Protection",
        icon: CuteRobotIcon,
      }}
    >
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
        <DashboardStat
          label="Threat Level"
          value="LOW"
          description="Current status"
          icon={CuteRobotIcon}
          tag="SECURE"
          intent="positive"
        />
        <DashboardStat
          label="Blocked Attacks"
          value="1,247"
          description="Last 24 hours"
          icon={BoomIcon}
          intent="positive"
          direction="up"
        />
        <DashboardStat
          label="System Integrity"
          value="99.9%"
          description="All systems"
          icon={GearIcon}
          intent="positive"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <DashboardCard title="Security Protocols" intent="success">
          <div className="space-y-4">
            <div className="flex justify-between items-center p-3 bg-accent/50 rounded">
              <div>
                <h4 className="font-medium">Firewall Protection</h4>
                <p className="text-sm text-muted-foreground">Advanced filtering active</p>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span className="text-xs font-mono">ACTIVE</span>
              </div>
            </div>
            <div className="flex justify-between items-center p-3 bg-accent/50 rounded">
              <div>
                <h4 className="font-medium">Intrusion Detection</h4>
                <p className="text-sm text-muted-foreground">Real-time monitoring</p>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span className="text-xs font-mono">ACTIVE</span>
              </div>
            </div>
            <div className="flex justify-between items-center p-3 bg-accent/50 rounded">
              <div>
                <h4 className="font-medium">Encryption Layer</h4>
                <p className="text-sm text-muted-foreground">AES-256 encryption</p>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span className="text-xs font-mono">ACTIVE</span>
              </div>
            </div>
          </div>
        </DashboardCard>

        <DashboardCard title="Recent Security Events">
          <div className="space-y-4">
            <div className="p-3 bg-accent/50 rounded">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h4 className="font-medium text-sm">Suspicious Login Attempt</h4>
                  <p className="text-xs text-muted-foreground">IP: 192.168.1.999</p>
                </div>
                <span className="text-xs text-destructive font-mono">BLOCKED</span>
              </div>
              <p className="text-xs text-muted-foreground">2 minutes ago</p>
            </div>
            <div className="p-3 bg-accent/50 rounded">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h4 className="font-medium text-sm">Port Scan Detected</h4>
                  <p className="text-xs text-muted-foreground">IP: 10.0.0.123</p>
                </div>
                <span className="text-xs text-destructive font-mono">BLOCKED</span>
              </div>
              <p className="text-xs text-muted-foreground">15 minutes ago</p>
            </div>
            <div className="p-3 bg-accent/50 rounded">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h4 className="font-medium text-sm">System Update Applied</h4>
                  <p className="text-xs text-muted-foreground">Security patch v2.1.4</p>
                </div>
                <span className="text-xs text-success font-mono">SUCCESS</span>
              </div>
              <p className="text-xs text-muted-foreground">1 hour ago</p>
            </div>
          </div>
        </DashboardCard>
      </div>
    </DashboardPageLayout>
  )
}
