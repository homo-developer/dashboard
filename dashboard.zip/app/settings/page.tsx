import DashboardPageLayout from "@/components/dashboard/layout"
import DashboardCard from "@/components/dashboard/card"
import GearIcon from "@/components/icons/gear"

export default function SettingsPage() {
  return (
    <DashboardPageLayout
      header={{
        title: "Settings",
        description: "System Preferences",
        icon: GearIcon,
      }}
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <DashboardCard title="Interface Settings">
          <div className="space-y-4">
            <div className="flex justify-between items-center p-3 bg-accent/50 rounded">
              <div>
                <h4 className="font-medium">Dark Mode</h4>
                <p className="text-sm text-muted-foreground">System appearance</p>
              </div>
              <div className="w-2 h-2 bg-success rounded-full"></div>
            </div>
            <div className="flex justify-between items-center p-3 bg-accent/50 rounded">
              <div>
                <h4 className="font-medium">Animations</h4>
                <p className="text-sm text-muted-foreground">UI transitions</p>
              </div>
              <div className="w-2 h-2 bg-success rounded-full"></div>
            </div>
            <div className="flex justify-between items-center p-3 bg-accent/50 rounded">
              <div>
                <h4 className="font-medium">Sound Effects</h4>
                <p className="text-sm text-muted-foreground">Audio feedback</p>
              </div>
              <div className="w-2 h-2 bg-muted-foreground rounded-full"></div>
            </div>
          </div>
        </DashboardCard>

        <DashboardCard title="Notification Settings">
          <div className="space-y-4">
            <div className="flex justify-between items-center p-3 bg-accent/50 rounded">
              <div>
                <h4 className="font-medium">Security Alerts</h4>
                <p className="text-sm text-muted-foreground">Critical notifications</p>
              </div>
              <div className="w-2 h-2 bg-success rounded-full"></div>
            </div>
            <div className="flex justify-between items-center p-3 bg-accent/50 rounded">
              <div>
                <h4 className="font-medium">System Updates</h4>
                <p className="text-sm text-muted-foreground">Maintenance notices</p>
              </div>
              <div className="w-2 h-2 bg-success rounded-full"></div>
            </div>
            <div className="flex justify-between items-center p-3 bg-accent/50 rounded">
              <div>
                <h4 className="font-medium">Experiment Results</h4>
                <p className="text-sm text-muted-foreground">Lab notifications</p>
              </div>
              <div className="w-2 h-2 bg-warning rounded-full"></div>
            </div>
          </div>
        </DashboardCard>

        <DashboardCard title="Privacy & Security">
          <div className="space-y-4">
            <div className="p-3 bg-accent/50 rounded">
              <h4 className="font-medium mb-2">Two-Factor Authentication</h4>
              <p className="text-sm text-muted-foreground mb-3">Add an extra layer of security to your account</p>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span className="text-xs font-mono text-success">ENABLED</span>
              </div>
            </div>
            <div className="p-3 bg-accent/50 rounded">
              <h4 className="font-medium mb-2">Session Timeout</h4>
              <p className="text-sm text-muted-foreground mb-3">Automatically log out after inactivity</p>
              <span className="text-xs font-mono">30 minutes</span>
            </div>
            <div className="p-3 bg-accent/50 rounded">
              <h4 className="font-medium mb-2">Data Encryption</h4>
              <p className="text-sm text-muted-foreground mb-3">All data is encrypted using AES-256</p>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span className="text-xs font-mono text-success">ACTIVE</span>
              </div>
            </div>
          </div>
        </DashboardCard>

        <DashboardCard title="System Information">
          <div className="space-y-4">
            <div className="p-3 bg-accent/50 rounded">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">M.O.N.K.Y OS Version</span>
                <span className="text-sm font-mono">v2.4.1</span>
              </div>
            </div>
            <div className="p-3 bg-accent/50 rounded">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Build Number</span>
                <span className="text-sm font-mono">#2024.12.07</span>
              </div>
            </div>
            <div className="p-3 bg-accent/50 rounded">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Last Update</span>
                <span className="text-sm font-mono">2024-12-01</span>
              </div>
            </div>
            <div className="p-3 bg-accent/50 rounded">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">System Status</span>
                <span className="text-sm font-mono text-success">OPERATIONAL</span>
              </div>
            </div>
          </div>
        </DashboardCard>
      </div>
    </DashboardPageLayout>
  )
}
