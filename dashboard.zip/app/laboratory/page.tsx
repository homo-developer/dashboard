import DashboardPageLayout from "@/components/dashboard/layout"
import DashboardStat from "@/components/dashboard/stat"
import DashboardCard from "@/components/dashboard/card"
import AtomIcon from "@/components/icons/atom"
import GearIcon from "@/components/icons/gear"
import ProcessorIcon from "@/components/icons/proccesor"
import BoomIcon from "@/components/icons/boom"

export default function LaboratoryPage() {
  return (
    <DashboardPageLayout
      header={{
        title: "Laboratory",
        description: "Experimental Zone",
        icon: AtomIcon,
      }}
    >
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
        <DashboardStat
          label="Active Experiments"
          value="12"
          description="Running protocols"
          icon={AtomIcon}
          tag="LIVE"
          intent="positive"
          direction="up"
        />
        <DashboardStat
          label="Success Rate"
          value="87.3%"
          description="Last 30 days"
          icon={GearIcon}
          intent="positive"
        />
        <DashboardStat
          label="CPU Usage"
          value="64%"
          description="Processing power"
          icon={ProcessorIcon}
          intent="neutral"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <DashboardCard title="Research Projects" intent="success">
          <div className="space-y-4">
            <div className="flex justify-between items-center p-3 bg-accent/50 rounded">
              <div>
                <h4 className="font-medium">Neural Network Optimization</h4>
                <p className="text-sm text-muted-foreground">Phase 3 - Testing</p>
              </div>
              <span className="text-success font-mono">92%</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-accent/50 rounded">
              <div>
                <h4 className="font-medium">Quantum Computing Interface</h4>
                <p className="text-sm text-muted-foreground">Phase 2 - Development</p>
              </div>
              <span className="text-warning font-mono">67%</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-accent/50 rounded">
              <div>
                <h4 className="font-medium">AI Behavior Analysis</h4>
                <p className="text-sm text-muted-foreground">Phase 1 - Research</p>
              </div>
              <span className="text-muted-foreground font-mono">23%</span>
            </div>
          </div>
        </DashboardCard>

        <DashboardCard title="Lab Equipment Status">
          <div className="space-y-4">
            <div className="flex justify-between items-center p-3 bg-accent/50 rounded">
              <div className="flex items-center gap-3">
                <ProcessorIcon className="size-5" />
                <div>
                  <h4 className="font-medium">Quantum Processor</h4>
                  <p className="text-sm text-muted-foreground">Online</p>
                </div>
              </div>
              <div className="w-2 h-2 bg-success rounded-full"></div>
            </div>
            <div className="flex justify-between items-center p-3 bg-accent/50 rounded">
              <div className="flex items-center gap-3">
                <AtomIcon className="size-5" />
                <div>
                  <h4 className="font-medium">Particle Accelerator</h4>
                  <p className="text-sm text-muted-foreground">Maintenance</p>
                </div>
              </div>
              <div className="w-2 h-2 bg-warning rounded-full"></div>
            </div>
            <div className="flex justify-between items-center p-3 bg-accent/50 rounded">
              <div className="flex items-center gap-3">
                <BoomIcon className="size-5" />
                <div>
                  <h4 className="font-medium">Neural Interface</h4>
                  <p className="text-sm text-muted-foreground">Offline</p>
                </div>
              </div>
              <div className="w-2 h-2 bg-destructive rounded-full"></div>
            </div>
          </div>
        </DashboardCard>
      </div>
    </DashboardPageLayout>
  )
}
