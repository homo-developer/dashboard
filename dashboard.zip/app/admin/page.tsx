import DashboardPageLayout from "@/components/dashboard/layout"
import DashboardCard from "@/components/dashboard/card"
import GearIcon from "@/components/icons/gear"
import LockIcon from "@/components/icons/lock"

export default function AdminPage() {
  return (
    <DashboardPageLayout
      header={{
        title: "Admin Settings",
        description: "System Administration",
        icon: GearIcon,
      }}
    >
      <div className="flex items-center justify-center min-h-[400px]">
        <DashboardCard title="Access Restricted">
          <div className="text-center py-12">
            <LockIcon className="size-16 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-xl font-display mb-2">Administrative Access Required</h3>
            <p className="text-muted-foreground mb-6">
              This section requires elevated privileges to access system administration features.
            </p>
            <div className="space-y-2 text-sm text-muted-foreground">
              <p>• User Management</p>
              <p>• System Configuration</p>
              <p>• Security Settings</p>
              <p>• Network Administration</p>
            </div>
          </div>
        </DashboardCard>
      </div>
    </DashboardPageLayout>
  )
}
