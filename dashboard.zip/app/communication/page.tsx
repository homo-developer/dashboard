import DashboardPageLayout from "@/components/dashboard/layout"
import DashboardStat from "@/components/dashboard/stat"
import DashboardCard from "@/components/dashboard/card"
import EmailIcon from "@/components/icons/email"
import GearIcon from "@/components/icons/gear"
import BoomIcon from "@/components/icons/boom"

export default function CommunicationPage() {
  return (
    <DashboardPageLayout
      header={{
        title: "Communication",
        description: "Network & Messaging",
        icon: EmailIcon,
      }}
    >
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
        <DashboardStat
          label="Active Channels"
          value="8"
          description="Open connections"
          icon={EmailIcon}
          tag="LIVE"
          intent="positive"
          direction="up"
        />
        <DashboardStat
          label="Messages Sent"
          value="2,847"
          description="Last 24 hours"
          icon={BoomIcon}
          intent="positive"
          direction="up"
        />
        <DashboardStat
          label="Network Latency"
          value="12ms"
          description="Average response"
          icon={GearIcon}
          intent="positive"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <DashboardCard title="Communication Channels" intent="success">
          <div className="space-y-4">
            <div className="flex justify-between items-center p-3 bg-accent/50 rounded">
              <div>
                <h4 className="font-medium">Secure Channel Alpha</h4>
                <p className="text-sm text-muted-foreground">Encrypted relay - Priority 1</p>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span className="text-xs font-mono">ACTIVE</span>
              </div>
            </div>
            <div className="flex justify-between items-center p-3 bg-accent/50 rounded">
              <div>
                <h4 className="font-medium">Broadcast Network</h4>
                <p className="text-sm text-muted-foreground">Public announcements</p>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span className="text-xs font-mono">ACTIVE</span>
              </div>
            </div>
            <div className="flex justify-between items-center p-3 bg-accent/50 rounded">
              <div>
                <h4 className="font-medium">Emergency Protocol</h4>
                <p className="text-sm text-muted-foreground">Crisis communication</p>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-warning rounded-full"></div>
                <span className="text-xs font-mono">STANDBY</span>
              </div>
            </div>
          </div>
        </DashboardCard>

        <DashboardCard title="Recent Messages">
          <div className="space-y-4">
            <div className="p-3 bg-accent/50 rounded">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h4 className="font-medium text-sm">System Status Update</h4>
                  <p className="text-xs text-muted-foreground">From: KRIMSON</p>
                </div>
                <span className="text-xs text-success font-mono">SENT</span>
              </div>
              <p className="text-xs text-muted-foreground mb-2">
                All systems operational. Laboratory experiments proceeding as scheduled.
              </p>
              <p className="text-xs text-muted-foreground">5 minutes ago</p>
            </div>
            <div className="p-3 bg-accent/50 rounded">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h4 className="font-medium text-sm">Security Alert Cleared</h4>
                  <p className="text-xs text-muted-foreground">From: Security Bot</p>
                </div>
                <span className="text-xs text-muted-foreground font-mono">RECEIVED</span>
              </div>
              <p className="text-xs text-muted-foreground mb-2">
                Threat level reduced to LOW. All protocols functioning normally.
              </p>
              <p className="text-xs text-muted-foreground">23 minutes ago</p>
            </div>
            <div className="p-3 bg-accent/50 rounded">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h4 className="font-medium text-sm">Device Maintenance Complete</h4>
                  <p className="text-xs text-muted-foreground">From: Tech Support</p>
                </div>
                <span className="text-xs text-muted-foreground font-mono">RECEIVED</span>
              </div>
              <p className="text-xs text-muted-foreground mb-2">
                Particle accelerator maintenance completed successfully.
              </p>
              <p className="text-xs text-muted-foreground">1 hour ago</p>
            </div>
          </div>
        </DashboardCard>
      </div>
    </DashboardPageLayout>
  )
}
