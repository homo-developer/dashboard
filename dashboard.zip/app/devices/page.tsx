import DashboardPageLayout from "@/components/dashboard/layout"
import DashboardStat from "@/components/dashboard/stat"
import DashboardCard from "@/components/dashboard/card"
import ProcessorIcon from "@/components/icons/proccesor"
import GearIcon from "@/components/icons/gear"
import BoomIcon from "@/components/icons/boom"

export default function DevicesPage() {
  return (
    <DashboardPageLayout
      header={{
        title: "Devices",
        description: "Hardware Management",
        icon: ProcessorIcon,
      }}
    >
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
        <DashboardStat
          label="Connected Devices"
          value="24"
          description="Active connections"
          icon={ProcessorIcon}
          tag="ONLINE"
          intent="positive"
          direction="up"
        />
        <DashboardStat
          label="Network Load"
          value="45.2%"
          description="Bandwidth usage"
          icon={GearIcon}
          intent="neutral"
        />
        <DashboardStat
          label="System Health"
          value="98.7%"
          description="Overall status"
          icon={BoomIcon}
          intent="positive"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <DashboardCard title="Device Registry" intent="success">
          <div className="space-y-4">
            <div className="flex justify-between items-center p-3 bg-accent/50 rounded">
              <div className="flex items-center gap-3">
                <ProcessorIcon className="size-5" />
                <div>
                  <h4 className="font-medium">Workstation Alpha</h4>
                  <p className="text-sm text-muted-foreground">192.168.1.100</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span className="text-xs font-mono">ACTIVE</span>
              </div>
            </div>
            <div className="flex justify-between items-center p-3 bg-accent/50 rounded">
              <div className="flex items-center gap-3">
                <ProcessorIcon className="size-5" />
                <div>
                  <h4 className="font-medium">Server Beta</h4>
                  <p className="text-sm text-muted-foreground">192.168.1.101</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-success rounded-full"></div>
                <span className="text-xs font-mono">ACTIVE</span>
              </div>
            </div>
            <div className="flex justify-between items-center p-3 bg-accent/50 rounded">
              <div className="flex items-center gap-3">
                <ProcessorIcon className="size-5" />
                <div>
                  <h4 className="font-medium">Mobile Unit Gamma</h4>
                  <p className="text-sm text-muted-foreground">192.168.1.102</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-warning rounded-full"></div>
                <span className="text-xs font-mono">IDLE</span>
              </div>
            </div>
          </div>
        </DashboardCard>

        <DashboardCard title="Performance Metrics">
          <div className="space-y-4">
            <div className="p-3 bg-accent/50 rounded">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium">CPU Usage</span>
                <span className="text-sm font-mono">67%</span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div className="bg-primary h-2 rounded-full" style={{ width: "67%" }}></div>
              </div>
            </div>
            <div className="p-3 bg-accent/50 rounded">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium">Memory Usage</span>
                <span className="text-sm font-mono">82%</span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div className="bg-warning h-2 rounded-full" style={{ width: "82%" }}></div>
              </div>
            </div>
            <div className="p-3 bg-accent/50 rounded">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium">Storage Usage</span>
                <span className="text-sm font-mono">34%</span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div className="bg-success h-2 rounded-full" style={{ width: "34%" }}></div>
              </div>
            </div>
          </div>
        </DashboardCard>
      </div>
    </DashboardPageLayout>
  )
}
