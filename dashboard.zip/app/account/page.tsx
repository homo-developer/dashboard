import DashboardPageLayout from "@/components/dashboard/layout"
import DashboardCard from "@/components/dashboard/card"
import MonkeyIcon from "@/components/icons/monkey"
import Image from "next/image"

export default function AccountPage() {
  return (
    <DashboardPageLayout
      header={{
        title: "Account",
        description: "User Profile Management",
        icon: MonkeyIcon,
      }}
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <DashboardCard title="Profile Information">
          <div className="space-y-6">
            <div className="flex items-center gap-4">
              <div className="size-16 rounded-lg overflow-hidden bg-primary">
                <Image
                  src="/avatars/user_krimson.png"
                  alt="KRIMSON"
                  width={64}
                  height={64}
                  className="size-full object-cover"
                />
              </div>
              <div>
                <h3 className="text-xl font-display">KRIMSON</h3>
                <p className="text-sm text-muted-foreground">krimson@joyco.studio</p>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Display Name</label>
                <div className="mt-1 p-3 bg-accent/50 rounded font-mono">KRIMSON</div>
              </div>
              <div>
                <label className="text-sm font-medium">Email Address</label>
                <div className="mt-1 p-3 bg-accent/50 rounded font-mono">krimson@joyco.studio</div>
              </div>
              <div>
                <label className="text-sm font-medium">User ID</label>
                <div className="mt-1 p-3 bg-accent/50 rounded font-mono">#USR-2024-001</div>
              </div>
              <div>
                <label className="text-sm font-medium">Access Level</label>
                <div className="mt-1 p-3 bg-accent/50 rounded font-mono">REBEL OPERATIVE</div>
              </div>
            </div>
          </div>
        </DashboardCard>

        <DashboardCard title="Account Statistics">
          <div className="space-y-4">
            <div className="p-3 bg-accent/50 rounded">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Account Created</span>
                <span className="text-sm font-mono">2024-01-15</span>
              </div>
            </div>
            <div className="p-3 bg-accent/50 rounded">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Last Login</span>
                <span className="text-sm font-mono">2024-12-07 14:32</span>
              </div>
            </div>
            <div className="p-3 bg-accent/50 rounded">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Sessions Today</span>
                <span className="text-sm font-mono">3</span>
              </div>
            </div>
            <div className="p-3 bg-accent/50 rounded">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Total Experiments</span>
                <span className="text-sm font-mono">247</span>
              </div>
            </div>
            <div className="p-3 bg-accent/50 rounded">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Security Clearance</span>
                <span className="text-sm font-mono text-success">LEVEL 7</span>
              </div>
            </div>
          </div>
        </DashboardCard>
      </div>
    </DashboardPageLayout>
  )
}
